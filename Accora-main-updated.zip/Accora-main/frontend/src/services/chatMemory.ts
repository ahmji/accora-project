/**
 * Chat memory for the Accora AI Co-Pilot.
 *
 * - "Learned facts": short statements the AI picks up about the user and their
 *   business (e.g. "Runs a bakery in Lahore with 4 staff"). They are sent with every
 *   question so answers get more personal over time.
 * - "Conversation": the recent chat, so it survives page refreshes.
 *
 * Everything is stored in this browser only, separately for each signed-in user.
 */

import { getStoredUser } from './auth';

const MAX_FACTS = 50;
const MAX_SAVED_MESSAGES = 60;

function userKey(kind: 'memory' | 'conversation'): string {
  const user = getStoredUser();
  const id = user?.id || user?.email || 'guest';
  return `accora_ai_${kind}_v1:${id}`;
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full or unavailable: the chat still works, it just won't remember */
  }
}

/* ── Learned facts ─────────────────────────────────────────────── */

export function loadMemory(): string[] {
  const items = readJson<unknown>(userKey('memory'), []);
  return Array.isArray(items) ? items.filter((i): i is string => typeof i === 'string') : [];
}

export function saveMemory(items: string[]): string[] {
  const seen = new Set<string>();
  const clean: string[] = [];
  for (const item of items) {
    const text = item.trim();
    const k = text.toLowerCase();
    if (text && !seen.has(k)) {
      seen.add(k);
      clean.push(text);
    }
  }
  const trimmed = clean.slice(-MAX_FACTS);
  writeJson(userKey('memory'), trimmed);
  return trimmed;
}

export function addToMemory(newItems: string[] | undefined): string[] {
  if (!newItems || newItems.length === 0) return loadMemory();
  return saveMemory([...loadMemory(), ...newItems]);
}

export function removeFromMemory(item: string): string[] {
  return saveMemory(loadMemory().filter((m) => m !== item));
}

export function clearMemory(): string[] {
  return saveMemory([]);
}

/* ── Saved conversation ────────────────────────────────────────── */

export function loadConversation<T>(): T[] {
  const items = readJson<unknown>(userKey('conversation'), []);
  return Array.isArray(items) ? (items as T[]) : [];
}

export function saveConversation<T>(messages: T[]): void {
  writeJson(userKey('conversation'), messages.slice(-MAX_SAVED_MESSAGES));
}

export function clearConversation(): void {
  try {
    localStorage.removeItem(userKey('conversation'));
  } catch {
    /* ignore */
  }
}
