"""Tests for Google Gemini AI Provider and multi-turn conversational chat."""

import json
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from fastapi.testclient import TestClient

from app.ai.gemini import GeminiAIProvider
from app.ai.provider import get_ai_provider
from app.core.config import settings
from app.main import app
from app.models.financial import ChatMessage, ChatRequest


@pytest.mark.anyio
async def test_gemini_fallback_when_no_key():
    """GeminiAIProvider should fall back gracefully to MockAIProvider when key is missing."""
    provider = GeminiAIProvider(api_key="")
    req = ChatRequest(message="What is my cash runway?", history=[])
    res = await provider.chat(req, context="Revenue: PKR 1,000,000\nExpenses: PKR 500,000\nCash balance: PKR 2,000,000")
    assert res.answer
    assert "cash" in res.answer.lower() or "balance" in res.answer.lower()
    assert len(res.evidence) > 0


@pytest.mark.anyio
async def test_gemini_json_cleaning():
    """Verify markdown fences are cleanly stripped from model output."""
    provider = GeminiAIProvider(api_key="mock_key")
    raw_json_in_markdown = """```json
    {
      "answer": "You have a solid 4 months of runway.",
      "evidence": ["Cash balance is PKR 2M", "Burn rate is PKR 500k"],
      "interpretation": "Your liquidity is within safe operating margins.",
      "recommendation": "Maintain buffer and accelerate collection of pending invoices.",
      "follow_ups": ["Can I hire someone?", "How can I cut expenses?"]
    }
    ```"""
    cleaned = provider._clean_json_text(raw_json_in_markdown)
    assert not cleaned.startswith("```")
    assert not cleaned.endswith("```")
    data = json.loads(cleaned)
    assert data["answer"] == "You have a solid 4 months of runway."
    assert len(data["evidence"]) == 2


@pytest.mark.anyio
async def test_gemini_chat_successful_call():
    """Test full chat response parsing when Gemini API returns valid JSON."""
    provider = GeminiAIProvider(api_key="test_key_123", model_id="gemini-1.5-flash")
    mock_payload = {
        "candidates": [
            {
                "content": {
                    "parts": [
                        {
                            "text": json.dumps({
                                "answer": "Based on your records, your net profit margin is 32%.",
                                "evidence": ["Revenue: PKR 1.5M", "Expenses: PKR 1.02M", "Profit: PKR 480K"],
                                "interpretation": "A 32% margin gives strong operational stability for an agency.",
                                "recommendation": "Reinvest surplus into growth marketing.",
                                "follow_ups": ["Can I afford a new hire?", "What are my overdue invoices?"]
                            })
                        }
                    ],
                    "role": "model",
                },
                "finishReason": "STOP",
            }
        ]
    }

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = mock_payload

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_resp
        req = ChatRequest(
            message="What is my margin?",
            history=[
                ChatMessage(role="user", content="Hi!"),
                ChatMessage(role="model", content="Salam! How can I assist you with your finances today?"),
            ],
        )
        res = await provider.chat(req, context="Revenue: PKR 1.5M\nExpenses: PKR 1.02M")
        assert res.answer == "Based on your records, your net profit margin is 32%."
        assert len(res.evidence) == 3
        assert res.interpretation == "A 32% margin gives strong operational stability for an agency."
        assert len(res.follow_ups) == 2


def test_ai_status_endpoint():
    """Verify /api/v1/ai/status endpoint responds with provider metadata."""
    with TestClient(app) as client:
        resp = client.get("/api/v1/ai/status")
        assert resp.status_code == 200
        data = resp.json()
        assert "status" in data
        assert "provider" in data
        assert "model" in data
        assert "configured" in data


# ---------------------------------------------------------------------------
# Smart co-pilot: learning memory, model fallback and clear error notices
# ---------------------------------------------------------------------------

def _gemini_ok(payload: dict) -> MagicMock:
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {
        "candidates": [{"content": {"role": "model", "parts": [{"text": json.dumps(payload)}]}}]
    }
    return resp


def _gemini_err(status: int, text: str = "error") -> MagicMock:
    resp = MagicMock()
    resp.status_code = status
    resp.text = text
    return resp


@pytest.fixture(autouse=True)
def _reset_working_model():
    GeminiAIProvider._working_model = None
    yield
    GeminiAIProvider._working_model = None


@pytest.mark.anyio
async def test_chat_learns_new_facts_and_sends_memory():
    provider = GeminiAIProvider(api_key="k", model_id="gemini-flash-latest")
    payload = {
        "answer": "Yes, with **PKR 160,000** monthly profit you can afford it.",
        "evidence": ["Profit: PKR 160,000"],
        "follow_ups": ["What about two hires?"],
        "remember": [
            "Runs a bakery in Lahore",           # new -> learned
            "Has 4 employees",                   # already known -> skipped
            "Bank account number is 12345678",   # sensitive -> never stored
        ],
    }
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = _gemini_ok(payload)
        res = await provider.chat(
            ChatRequest(message="I run a bakery in Lahore. Can I hire?", memory=["Has 4 employees"]),
            context="Profit: PKR 160,000",
        )
        sent = mock_post.call_args.kwargs
        assert "Has 4 employees" in sent["json"]["systemInstruction"]["parts"][0]["text"]
        # The key travels in a header, never in the URL (keeps it out of logs)
        assert sent["headers"]["x-goog-api-key"] == "k"
        assert "key=" not in mock_post.call_args.args[0]

    assert res.source == "gemini"
    assert res.model == "gemini-flash-latest"
    assert res.learned == ["Runs a bakery in Lahore"]
    assert res.notice == ""


@pytest.mark.anyio
async def test_chat_tries_next_model_when_one_is_unavailable():
    provider = GeminiAIProvider(api_key="k", model_id="gemini-old-model")
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.side_effect = [_gemini_err(404, "not found"), _gemini_ok({"answer": "Hello!"})]
        res = await provider.chat(ChatRequest(message="hi"), context="")
    assert res.answer == "Hello!"
    assert res.source == "gemini"
    assert res.model == "gemini-flash-latest"


@pytest.mark.anyio
async def test_chat_reports_invalid_key_clearly():
    provider = GeminiAIProvider(api_key="bad")
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = _gemini_err(400, '{"error": {"message": "API key not valid."}}')
        res = await provider.chat(ChatRequest(message="What is my cash balance?"), context="Cash balance: PKR 5")
        assert mock_post.call_count == 1  # no point trying other models with a bad key
    assert res.source == "fallback"
    assert "API key" in res.notice
    assert res.answer  # still gets a basic offline answer


@pytest.mark.anyio
async def test_chat_without_key_explains_why():
    res = await GeminiAIProvider(api_key="").chat(ChatRequest(message="hi"), context="")
    assert res.source == "fallback"
    assert "no Gemini API key" in res.notice


@pytest.mark.anyio
async def test_plain_text_reply_is_still_used():
    provider = GeminiAIProvider(api_key="k")
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"candidates": [{"content": {"parts": [{"text": "Just a plain answer."}]}}]}
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = resp
        res = await provider.chat(ChatRequest(message="hi"), context="")
    assert res.answer == "Just a plain answer."
    assert res.source == "gemini"


def test_ai_test_endpoint_never_leaks_key():
    with TestClient(app) as client:
        with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
            resp_ok = MagicMock()
            resp_ok.status_code = 200
            resp_ok.json.return_value = {"candidates": [{"content": {"parts": [{"text": "OK"}]}}]}
            mock_post.return_value = resp_ok
            with patch.object(settings, "gemini_api_key", "secret-key-value"):
                data = client.get("/api/v1/ai/test").json()
    assert data["connected"] is True
    assert "secret-key-value" not in json.dumps(data)
