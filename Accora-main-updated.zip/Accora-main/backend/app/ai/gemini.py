"""Google Gemini AI service provider for Accora AI Co-Pilot.

Integrates Google Generative Language API (Gemini models) to provide:
- A smart, conversational business co-pilot that can answer any business question,
  grounded in the user's own financial records whenever they are relevant
- Learning memory: the model extracts durable facts the user shares about
  themselves and their business, which the app stores and sends back next time
- Proactive AI financial insights
- Strategic scenario / what-if simulations
- Executive business health commentary and summaries
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

import httpx

from app.analytics.engine import compute_health_score
from app.core.config import settings
from app.models.financial import (
    AIInsight,
    BusinessHealthScore,
    BusinessSummary,
    ChatMessage,
    ChatRequest,
    ChatResponse,
    FinancialMetrics,
    InsightSeverity,
    InsightType,
    Invoice,
    InvoiceStatus,
    Transaction,
    WhatIfRequest,
    WhatIfResult,
)

logger = logging.getLogger("accora.ai.gemini")

# Models tried, in order, after the one configured in ACCORA_GEMINI_MODEL.
# "-latest" aliases are maintained by Google and always point at a current model,
# so the app keeps working when older model versions are retired.
FALLBACK_MODELS: tuple[str, ...] = (
    "gemini-flash-latest",
    "gemini-2.5-flash",
    "gemini-flash-lite-latest",
    "gemini-2.5-flash-lite",
)

# Limits that keep requests small, fast and cheap.
MAX_HISTORY_MESSAGES = 20
MAX_MEMORY_ITEMS = 50
MAX_MEMORY_ITEM_CHARS = 240
MAX_NEW_MEMORIES_PER_TURN = 3

# Things the co-pilot must never store in its memory.
_SENSITIVE_MEMORY_PATTERN = re.compile(
    r"password|passcode|\bpin\b|otp|cvv|card number|iban|account number|cnic|api key|secret",
    re.IGNORECASE,
)


class GeminiError(Exception):
    """A Gemini failure with a short, safe, human-readable reason (never contains the key)."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class GeminiAIProvider:
    """Production provider using Google Gemini API."""

    # Remembers which model answered successfully so later calls skip dead models.
    _working_model: str | None = None

    def __init__(
        self,
        api_key: str | None = None,
        model_id: str | None = None,
        endpoint: str | None = None,
    ) -> None:
        raw_key = (api_key if api_key is not None else settings.gemini_api_key or "").strip()
        if raw_key.lower().startswith("api key "):
            raw_key = raw_key[8:].strip()
        elif raw_key.lower().startswith("bearer "):
            raw_key = raw_key[7:].strip()
        self.api_key = raw_key
        self.model_id = (model_id or settings.gemini_model_id or FALLBACK_MODELS[0]).strip()
        self.endpoint = (endpoint or settings.gemini_endpoint or "").strip()
        self._fallback_provider: Any = None
        self.last_model_used: str | None = None

    @property
    def fallback(self) -> Any:
        """Lazy load the mock provider as a safe resilience fallback."""
        if self._fallback_provider is None:
            from app.ai.provider import MockAIProvider
            self._fallback_provider = MockAIProvider()
        return self._fallback_provider

    def _get_api_url(self, model: str) -> str:
        """Build the Google Gemini API endpoint URL (the key is sent in a header, not the URL)."""
        base = self.endpoint.rstrip("/") if self.endpoint else "https://generativelanguage.googleapis.com"
        return f"{base}/v1beta/models/{model}:generateContent"

    def _candidate_models(self) -> list[str]:
        models: list[str] = []
        for m in (GeminiAIProvider._working_model, self.model_id, *FALLBACK_MODELS):
            if m and m not in models:
                models.append(m)
        return models

    @staticmethod
    def _extract_text(data: dict[str, Any]) -> str:
        """Join all visible text parts from a Gemini response (skips hidden 'thought' parts)."""
        feedback = data.get("promptFeedback") or {}
        if feedback.get("blockReason"):
            raise GeminiError(f"Gemini blocked the request ({feedback['blockReason']}).")
        candidates = data.get("candidates") or []
        if not candidates:
            raise GeminiError("Gemini returned an empty response.")
        parts = (candidates[0].get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        if not text.strip():
            reason = candidates[0].get("finishReason", "unknown")
            raise GeminiError(f"Gemini returned no text (finish reason: {reason}).")
        return text.strip()

    async def _call_gemini(
        self,
        system_instruction: str,
        contents: list[dict[str, Any]],
        temperature: float = 0.3,
        json_output: bool = True,
    ) -> str:
        """Call Gemini, automatically trying alternative models if one is unavailable or busy."""
        if not self.api_key:
            raise GeminiError(
                "No Gemini API key is set on the server. Add ACCORA_GEMINI_API_KEY to your "
                "environment variables and redeploy."
            )

        gen_config: dict[str, Any] = {"temperature": temperature}
        if json_output:
            gen_config["responseMimeType"] = "application/json"

        payload = {
            "systemInstruction": {"parts": [{"text": system_instruction}]},
            "contents": contents,
            "generationConfig": gen_config,
        }
        headers = {"Content-Type": "application/json", "x-goog-api-key": self.api_key}
        reasons: list[str] = []

        for model in self._candidate_models():
            try:
                async with httpx.AsyncClient(timeout=60.0) as client:
                    resp = await client.post(self._get_api_url(model), json=payload, headers=headers)
            except httpx.RequestError as exc:
                logger.warning("Network error calling Gemini model %s: %s", model, exc)
                reasons.append(f"{model}: network error")
                continue

            if resp.status_code == 200:
                text = self._extract_text(resp.json())
                GeminiAIProvider._working_model = model
                self.last_model_used = model
                return text

            body = resp.text[:500]
            logger.warning("Gemini model %s returned HTTP %s: %s", model, resp.status_code, body)

            # Problems with the key itself: trying other models will not help.
            if resp.status_code in (401, 403) or (
                resp.status_code == 400 and ("API key" in body or "API_KEY" in body)
            ):
                raise GeminiError(
                    "Google rejected the Gemini API key. Check that ACCORA_GEMINI_API_KEY is "
                    "copied correctly from https://aistudio.google.com/app/apikey."
                )

            if GeminiAIProvider._working_model == model:
                GeminiAIProvider._working_model = None

            if resp.status_code == 404:
                reasons.append(f"{model}: model not available")
            elif resp.status_code == 429:
                reasons.append(f"{model}: quota or rate limit reached")
            else:
                reasons.append(f"{model}: HTTP {resp.status_code}")

        raise GeminiError("Could not get an answer from Gemini (" + "; ".join(reasons) + ").")

    def _clean_json_text(self, text: str) -> str:
        """Strip markdown code fence blocks if returned by the model."""
        s = text.strip()
        if s.startswith("```"):
            s = re.sub(r"^```(?:json)?\s*", "", s, flags=re.IGNORECASE)
            s = re.sub(r"\s*```$", "", s)
        return s.strip()

    async def test_connection(self) -> dict[str, Any]:
        """Run a tiny live request so the owner can confirm Gemini is working."""
        try:
            reply = await self._call_gemini(
                system_instruction="You are a connectivity check. Reply with the single word: OK",
                contents=[{"role": "user", "parts": [{"text": "ping"}]}],
                temperature=0,
                json_output=False,
            )
            return {"connected": True, "model": self.last_model_used, "reply": reply[:40]}
        except GeminiError as exc:
            return {"connected": False, "model": None, "error": exc.reason}
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("Gemini connection test failed")
            return {"connected": False, "model": None, "error": f"Unexpected error: {type(exc).__name__}"}

    # -----------------------------------------------------------------------
    # 1. Conversational Chat (smart co-pilot with learning memory)
    # -----------------------------------------------------------------------

    @staticmethod
    def _clean_memory(items: list[str]) -> list[str]:
        cleaned: list[str] = []
        seen: set[str] = set()
        for item in items or []:
            text = " ".join(str(item).split())[:MAX_MEMORY_ITEM_CHARS]
            key = text.lower()
            if text and key not in seen and not _SENSITIVE_MEMORY_PATTERN.search(text):
                seen.add(key)
                cleaned.append(text)
        return cleaned[-MAX_MEMORY_ITEMS:]

    @staticmethod
    def _build_contents(history: list[ChatMessage], message: str) -> list[dict[str, Any]]:
        """Convert chat history into Gemini's alternating user/model format."""
        contents: list[dict[str, Any]] = []
        for msg in history[-MAX_HISTORY_MESSAGES:]:
            role = "model" if msg.role in ("model", "assistant", "ai", "accora") else "user"
            text = (msg.content or "").strip()
            if not text:
                continue
            if contents and contents[-1]["role"] == role:
                contents[-1]["parts"][0]["text"] += f"\n{text}"
            else:
                contents.append({"role": role, "parts": [{"text": text}]})

        while contents and contents[0]["role"] != "user":
            contents.pop(0)

        current = message.strip() or "Give me a quick overview of my business's financial health."
        if contents and contents[-1]["role"] == "user":
            contents[-1]["parts"][0]["text"] += f"\n{current}"
        else:
            contents.append({"role": "user", "parts": [{"text": current}]})
        return contents

    @staticmethod
    def _chat_system_instruction(context: str, memory: list[str]) -> str:
        memory_block = "\n".join(f"- {m}" for m in memory) if memory else "(nothing yet)"
        return (
            "You are Accora, a sharp, warm and practical AI business co-pilot for small business "
            "owners, shopkeepers, freelancers and startups, many of them in Pakistan. Think like an "
            "experienced CFO, business strategist and mentor in one.\n\n"
            "WHAT YOU CAN HELP WITH\n"
            "- Anything about running a business: cash flow, pricing, profit, costs, invoices and "
            "collections, budgeting, saving, loans, hiring, marketing, sales, growth strategy, "
            "operations, negotiation, taxes in general terms (e.g. FBR basics), kametis/committees, "
            "and everyday decisions like 'can I afford this?'.\n"
            "- General business knowledge questions too. You are not limited to the records below; "
            "use your own expertise freely, and connect it to the user's numbers when relevant.\n\n"
            "HOW TO ANSWER\n"
            "1. Lead with the direct answer, then explain briefly. Be specific and practical, not generic.\n"
            "2. When the question involves their business, use the real figures from the BUSINESS DATA "
            "below and do the maths for them (runway, margins, how much they can safely spend, etc.).\n"
            "3. Never invent figures about their business. If something needed isn't in the data, say "
            "so plainly, give your best general guidance, and ask for the missing detail.\n"
            "4. Use what you have LEARNED ABOUT THIS USER to personalise answers, without reciting it back.\n"
            "5. Reply in the user's language and style: English, Urdu, or Roman Urdu.\n"
            "6. Format the answer with light Markdown: short paragraphs, **bold** for key numbers, and "
            "'- ' bullet lists where they help. No headings, no tables. Keep it focused.\n"
            "7. For legal, tax filing or investment decisions, give useful general guidance and suggest "
            "confirming specifics with a qualified professional.\n"
            "8. Follow-ups and casual chat ('thanks', 'why?', 'what about next month?') should feel "
            "natural; refer back to the conversation.\n\n"
            "LEARNING\n"
            "In the 'remember' field, list up to 3 NEW, durable facts the user has just told you about "
            "themselves or their business that would help in future conversations (e.g. 'Runs a "
            "bakery in Lahore with 4 staff', 'Wants to open a second branch next year', 'Prefers "
            "short answers'). Write each as a short third-person statement. Do not repeat what is "
            "already learned, do not store one-off questions, and never store passwords, card or "
            "account numbers, CNIC/ID numbers or other secrets. Use [] when there is nothing new.\n\n"
            "LEARNED ABOUT THIS USER\n"
            f"{memory_block}\n\n"
            "BUSINESS DATA\n"
            f"{context or '(no financial records available yet)'}\n\n"
            "OUTPUT\n"
            "Respond ONLY with a JSON object of this shape:\n"
            "{\n"
            '  "answer": "your full Markdown answer",\n'
            '  "evidence": ["0-4 exact figures from BUSINESS DATA you used; [] if none"],\n'
            '  "interpretation": "optional 1-2 sentences on why this matters; empty string if not useful",\n'
            '  "recommendation": "optional concrete next step; empty string if not useful",\n'
            '  "follow_ups": ["3 short, specific questions the user might ask next"],\n'
            '  "remember": ["0-3 new facts to learn"]\n'
            "}"
        )

    async def chat(self, request: ChatRequest, context: str) -> ChatResponse:
        """Answer a conversational query using the user's data, history and learned memory."""
        if not self.api_key:
            logger.info("No Gemini API key configured. Using the offline rule-based assistant.")
            return await self._fallback_chat(
                request,
                context,
                "AI is not connected yet (no Gemini API key on the server), so this is a basic "
                "offline answer.",
            )

        memory = self._clean_memory(request.memory)
        contents = self._build_contents(request.history, request.message)
        system_instruction = self._chat_system_instruction(context, memory)

        try:
            raw = await self._call_gemini(
                system_instruction=system_instruction,
                contents=contents,
                temperature=0.6,
                json_output=True,
            )
            try:
                data = json.loads(self._clean_json_text(raw))
            except json.JSONDecodeError:
                # The model replied in plain text; still a useful answer.
                data = {"answer": raw}
            if not isinstance(data, dict):
                data = {"answer": str(data)}

            def _str_list(value: Any) -> list[str]:
                if not isinstance(value, list):
                    return []
                return [str(v).strip() for v in value if str(v).strip()]

            answer = str(data.get("answer", "")).strip() or "Sorry, I couldn't form an answer. Could you rephrase?"
            existing = {m.lower() for m in memory}
            learned = [
                m for m in self._clean_memory(_str_list(data.get("remember")))
                if m.lower() not in existing
            ][:MAX_NEW_MEMORIES_PER_TURN]

            return ChatResponse(
                answer=answer,
                evidence=_str_list(data.get("evidence"))[:4],
                interpretation=str(data.get("interpretation", "") or "").strip(),
                recommendation=str(data.get("recommendation", "") or "").strip(),
                follow_ups=_str_list(data.get("follow_ups"))[:3],
                learned=learned,
                source="gemini",
                model=self.last_model_used or self.model_id,
            )

        except GeminiError as exc:
            logger.warning("Gemini chat failed: %s", exc.reason)
            return await self._fallback_chat(request, context, f"AI is temporarily unavailable: {exc.reason}")
        except Exception as exc:
            logger.exception("Unexpected error in Gemini chat")
            return await self._fallback_chat(
                request, context, f"AI is temporarily unavailable ({type(exc).__name__})."
            )

    async def _fallback_chat(self, request: ChatRequest, context: str, notice: str) -> ChatResponse:
        res = await self.fallback.chat(request, context)
        res.source = "fallback"
        res.notice = notice
        return res

    # -----------------------------------------------------------------------
    # 2. AI Insights
    # -----------------------------------------------------------------------

    async def generate_insights(
        self, metrics: list[FinancialMetrics], transactions: list[Transaction]
    ) -> list[AIInsight]:
        """Proactively detect risks, anomalies, and opportunities using Gemini."""
        if not metrics or not self.api_key:
            return await self.fallback.generate_insights(metrics, transactions)

        latest = metrics[-1]
        summary_lines = [
            f"Period: {latest.period}",
            f"Revenue: {latest.revenue:,.0f} (Change: {latest.revenue_change_pct:+.1f}%)",
            f"Expenses: {latest.expenses:,.0f} (Change: {latest.expenses_change_pct:+.1f}%)",
            f"Profit: {latest.profit:,.0f} (Margin: {latest.margin * 100:.1f}%)",
            f"Cash Flow: {latest.cash_flow:,.0f}",
            f"Cash Balance: {latest.cash_balance:,.0f}",
            "Expense Breakdown:",
        ]
        for cat, amt in sorted(latest.expense_breakdown.items(), key=lambda x: -x[1])[:5]:
            summary_lines.append(f"  {cat}: {amt:,.0f}")

        system_instruction = (
            "You are Accora Financial Intelligence Engine. Analyze the following business performance data "
            "and generate 2 to 4 high-impact, actionable insights categorized as RISK, OPPORTUNITY, or TREND.\n\n"
            "Return JSON array matching:\n"
            "[\n"
            "  {\n"
            '    "type": "risk" | "opportunity" | "trend" | "positive",\n'
            '    "severity": "low" | "medium" | "high",\n'
            '    "title": "Short punchy title",\n'
            '    "explanation": "Clear explanation of what is occurring and why",\n'
            '    "evidence": ["Supporting metric 1", "Supporting metric 2"],\n'
            '    "recommendation": "Concrete action for the business owner"\n'
            "  }\n"
            "]"
        )

        contents = [{
            "role": "user",
            "parts": [{"text": "\n".join(summary_lines)}],
        }]

        try:
            raw = await self._call_gemini(
                system_instruction=system_instruction,
                contents=contents,
                temperature=0.2,
                json_output=True,
            )
            cleaned = self._clean_json_text(raw)
            parsed = json.loads(cleaned)
            if not isinstance(parsed, list):
                parsed = parsed.get("insights", [])

            insights: list[AIInsight] = []
            type_map = {
                "risk": InsightType.RISK,
                "opportunity": InsightType.OPPORTUNITY,
                "trend": InsightType.TREND,
                "positive": InsightType.POSITIVE,
            }
            sev_map = {
                "low": InsightSeverity.LOW,
                "medium": InsightSeverity.MEDIUM,
                "high": InsightSeverity.HIGH,
            }

            for item in parsed:
                t = type_map.get(str(item.get("type", "")).lower(), InsightType.TREND)
                s = sev_map.get(str(item.get("severity", "")).lower(), InsightSeverity.MEDIUM)
                insights.append(
                    AIInsight(
                        type=t,
                        severity=s,
                        title=str(item.get("title", "Financial Observation")),
                        explanation=str(item.get("explanation", "")),
                        evidence=[str(e) for e in item.get("evidence", [])],
                        recommendation=str(item.get("recommendation", "")),
                    )
                )

            if insights:
                return insights
        except Exception as exc:
            logger.warning(f"Gemini generate_insights failed: {exc}. Falling back to default.")

        return await self.fallback.generate_insights(metrics, transactions)

    # -----------------------------------------------------------------------
    # 3. Business Health Analysis
    # -----------------------------------------------------------------------

    async def analyze_health(
        self, metrics: list[FinancialMetrics], transactions: list[Transaction]
    ) -> BusinessHealthScore:
        """Compute and explain business health score."""
        base_score = compute_health_score(metrics, transactions)
        if not self.api_key:
            return await self.fallback.analyze_health(metrics, transactions)

        latest = metrics[-1] if metrics else None
        if not latest:
            return base_score

        system_instruction = (
            "You are Accora AI Co-Pilot. Write a concise, 2-sentence executive interpretation and a "
            "1-sentence recommendation for the business based on their computed health score metrics.\n"
            "Return JSON: {\"interpretation\": \"...\", \"recommendation\": \"...\"}"
        )
        prompt = (
            f"Overall Health Score: {base_score.overall:.0f}/100 ({base_score.grade})\n"
            f"Liquidity: {base_score.liquidity:.0f}, Profitability: {base_score.profitability:.0f}, "
            f"Efficiency: {base_score.efficiency:.0f}, Solvency: {base_score.solvency:.0f}\n"
            f"Latest Revenue: {latest.revenue:,.0f}, Expenses: {latest.expenses:,.0f}, Cash: {latest.cash_balance:,.0f}"
        )

        try:
            raw = await self._call_gemini(
                system_instruction=system_instruction,
                contents=[{"role": "user", "parts": [{"text": prompt}]}],
                temperature=0.3,
                json_output=True,
            )
            cleaned = self._clean_json_text(raw)
            data = json.loads(cleaned)
            interp = str(data.get("interpretation", "")).strip()
            rec = str(data.get("recommendation", "")).strip()
            if interp:
                base_score.ai_interpretation = interp
            if rec:
                base_score.ai_recommendation = rec
        except Exception as exc:
            logger.warning(f"Gemini analyze_health commentary failed: {exc}")

        return base_score

    # -----------------------------------------------------------------------
    # 4. What-If Scenario Analysis
    # -----------------------------------------------------------------------

    async def what_if_analysis(
        self, request: WhatIfRequest, metrics: list[FinancialMetrics]
    ) -> WhatIfResult:
        """Run a what-if scenario and interpret results with Gemini."""
        # Use fallback deterministic calculations for base projections
        base_result = await self.fallback.what_if_analysis(request, metrics)
        if not self.api_key or not metrics:
            return base_result

        latest = metrics[-1]
        system_instruction = (
            "You are Accora Financial Strategist. Analyze this simulated business scenario.\n"
            "Return JSON: {\"ai_interpretation\": \"2-sentence financial interpretation\", \"recommendation\": \"1-sentence action step\"}"
        )
        prompt = (
            f"Scenario: {request.description} ({request.scenario_type})\n"
            f"Current: Revenue {latest.revenue:,.0f}, Expenses {latest.expenses:,.0f}, Profit {latest.profit:,.0f}\n"
            f"Projected: Revenue {base_result.projected_revenue:,.0f}, Expenses {base_result.projected_expenses:,.0f}, "
            f"Profit {base_result.projected_profit:,.0f}, Cash Flow {base_result.projected_cash_flow:,.0f}\n"
            f"Projected Health Score: {base_result.projected_health_score:.0f}"
        )

        try:
            raw = await self._call_gemini(
                system_instruction=system_instruction,
                contents=[{"role": "user", "parts": [{"text": prompt}]}],
                temperature=0.3,
                json_output=True,
            )
            cleaned = self._clean_json_text(raw)
            data = json.loads(cleaned)
            ai_interp = str(data.get("ai_interpretation", "")).strip()
            rec = str(data.get("recommendation", "")).strip()
            if ai_interp:
                base_result.ai_interpretation = ai_interp
            if rec:
                base_result.recommendation = rec
        except Exception as exc:
            logger.warning(f"Gemini what_if_analysis commentary failed: {exc}")

        return base_result

    # -----------------------------------------------------------------------
    # 5. Business Summary
    # -----------------------------------------------------------------------

    async def generate_business_summary(
        self, metrics: list[FinancialMetrics], invoices: list[Invoice]
    ) -> BusinessSummary:
        """Generate an executive business summary with Gemini."""
        if not metrics or not self.api_key:
            return await self.fallback.generate_business_summary(metrics, invoices)

        latest = metrics[-1]
        overdue = [inv for inv in invoices if inv.status == InvoiceStatus.OVERDUE]
        overdue_total = sum(inv.total for inv in overdue)

        system_instruction = (
            "You are Accora Chief Financial Officer AI. Generate an executive business performance summary.\n"
            "Return JSON:\n"
            "{\n"
            '  "ai_summary": "Comprehensive 3-4 sentence narrative covering revenue, margin, and cash health.",\n'
            '  "highlights": ["2-3 positive achievements or strengths"],\n'
            '  "concerns": ["1-3 financial warning signs or inefficiencies"],\n'
            '  "recommendations": ["2-3 high-priority strategic steps"]\n'
            "}"
        )

        prompt = (
            f"Latest Period: {latest.period}\n"
            f"Revenue: {latest.revenue:,.0f} (Growth: {latest.revenue_change_pct:+.1f}%)\n"
            f"Expenses: {latest.expenses:,.0f} (Growth: {latest.expenses_change_pct:+.1f}%)\n"
            f"Profit Margin: {latest.margin * 100:.1f}%\n"
            f"Cash Balance: {latest.cash_balance:,.0f}\n"
            f"Overdue Invoices: {len(overdue)} totaling {overdue_total:,.0f}"
        )

        try:
            raw = await self._call_gemini(
                system_instruction=system_instruction,
                contents=[{"role": "user", "parts": [{"text": prompt}]}],
                temperature=0.3,
                json_output=True,
            )
            cleaned = self._clean_json_text(raw)
            data = json.loads(cleaned)

            period_str = f"{metrics[0].period} to {latest.period}" if len(metrics) > 1 else latest.period
            return BusinessSummary(
                period=period_str,
                ai_summary=str(data.get("ai_summary", "")).strip(),
                highlights=[str(h) for h in data.get("highlights", [])],
                concerns=[str(c) for c in data.get("concerns", [])],
                recommendations=[str(r) for r in data.get("recommendations", [])],
            )
        except Exception as exc:
            logger.warning(f"Gemini generate_business_summary failed: {exc}")

        return await self.fallback.generate_business_summary(metrics, invoices)
